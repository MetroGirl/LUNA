                          MetroGirl @ Tokyo Demo Fest 2015
                                   mg-01: LUNA

credits:
--------
 dasyprocta
        : code
 masar key a.k.a crv/System K
        : code
 Saint NUS
        : music

system (minimum) requirements:
------------------------------
x86 cpu runs at 1.6Ghz
512mb ram
DirectX 11.0 compatible graphics card

libraries used in "LUNA":
-------------------------
ogg_static, vorbis_static, vorbisfile_static
Copyright (C) 1994-2002 XIPHOPHORUS Company http://www.xiph.org/

BASS
http://www.un4seen.com/

materials used in "LUNA":
-------------------------
The images of the Moon are made by John van Vliet.
These images are provided under the Creative Commons license (cc-by-sa).
http://www.celestiamotherlode.net/catalog/show_creator_details.php?creator_id=10

contacts:
---------
 dasyprocta
 twitter: @dasyprocta

 masar key
 twitter: @crv_the_coder
 email: masaaki@korematsu.jp
